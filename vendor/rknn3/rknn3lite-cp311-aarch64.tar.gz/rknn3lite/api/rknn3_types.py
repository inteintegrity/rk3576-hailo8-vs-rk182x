"""
RKNN3 Types and Structures Definition
This file contains all the type definitions, structures, enumerations, and constants
used by RKNN3 Toolkit Lite, similar to a C header file.
"""

import platform
import numpy as np
from ctypes import *
from enum import IntEnum, auto


# ============================================= Constants =============================================

# RKNN3 Maximum Values
RKNN3_MAX_DIMS = 16
RKNN3_MAX_STRIDE_DIMS = RKNN3_MAX_DIMS + 1
RKNN3_MAX_NAME_LEN = 256
RKNN3_MAX_DYNAMIC_SHAPE_NUM = 512
RKNN3_MAX_LORA_NUM = 32
RKNN3_MAX_DEVS = 64
RKNN3_MAX_DEV_LEN = 64
RKNN3_MAX_NPU_NODE_NUM = 128

# LLM Special Token Limits
RKNN3_MAX_SPECIAL_BOS_ID_NUM = 64  # maximum number of special Begin-Of-Sequence (BOS) token
RKNN3_MAX_SPECIAL_EOS_ID_NUM = 64  # maximum number of special End-Of-Sequence (EOS) token

# Library Path
LIBRKNN3RT_PATHS = ['/usr/lib/librknn3_api.so', '/usr/lib/librknn3_api_rkcp.so', '/usr/lib/librknn3_api_native.so']

# Context Types
if platform.architecture()[0] == '32bit':
    rknn3_context = c_uint32
else:
    rknn3_context = c_uint64

rknn3_session = c_void_p

# API Return Codes
rknn3_runtime_api_ret_code = {
    "0"  : "RKNN3_SUCCESS",
    "-1" : "RKNN3_ERR_FAIL",
    "-2" : "RKNN3_ERR_ARGUMENT_INVALID",
    "-3" : "RKNN3_ERR_MODEL_INVALID",
    "-4" : "RKNN3_ERR_CTX_INVALID",
    "-5" : "RKNN3_ERR_RUN_TASK_FAILED",
    "-6" : "RKNN3_ERR_OUT_OF_MEMORY",
    "-7" : "RKNN3_ERR_TIMEOUT",
    "-8" : "RKNN3_ERR_INPUT_INVALID",
    "-9" : "RKNN3_ERR_OUTPUT_INVALID",
    "-10": "RKNN3_ERR_DEVICE_UNAVAILABLE",
    "-11": "RKNN3_ERR_DEVICE_UNMATCH",
    "-12": "RKNN3_ERR_TARGET_PLATFORM_UNMATCH",
    "-13": "RKNN3_ERR_COMMUNICATION",
    "-14": "RKNN3_ERR_MEM_SYNC_FAILED",
    "-15": "RKNN3_ERR_KEY_INVALID",
    "-16": "RKNN3_ERR_DECRYPT_FAILED",
    "-17": "RKNN3_ERR_WEIGHT_LOAD_NOT_PREPARED",
    "-18": "RKNN3_ERR_INCOMPATIBLE_VERSION",
    "-100": "RKNN3_WARN_NPU_CORE_UNUSED",
}


# ============================================= Enumerations =============================================

class RKNN3QueryCmd(IntEnum):
    """Query command types for RKNN3"""
    RKNN3_QUERY_IN_OUT_NUM = 0
    RKNN3_QUERY_INPUT_ATTR = 1
    RKNN3_QUERY_OUTPUT_ATTR = 2

    # Deprecated by the current public header but kept as aliases for older SO compatibility.
    RKNN3_QUERY_PERF_DETAIL = 3
    RKNN3_QUERY_PERF_RUN = 4

    RKNN3_QUERY_SDK_VERSION = 5
    RKNN3_QUERY_CORE_MEM_SIZE = 6
    RKNN3_QUERY_CUSTOM_STRING = 7

    # New names in rknn3_api.h
    RKNN3_QUERY_ORIGIN_INPUT_ATTR = 8
    RKNN3_QUERY_ORIGIN_OUTPUT_ATTR = 9

    # Backward-compatible aliases used by older Python code.
    RKNN3_QUERY_NATIVE_INPUT_ATTR = RKNN3_QUERY_ORIGIN_INPUT_ATTR
    RKNN3_QUERY_NATIVE_OUTPUT_ATTR = RKNN3_QUERY_ORIGIN_OUTPUT_ATTR
    RKNN3_QUERY_NATIVE_NC1HWC2_INPUT_ATTR = RKNN3_QUERY_ORIGIN_INPUT_ATTR
    RKNN3_QUERY_NATIVE_NC1HWC2_OUTPUT_ATTR = RKNN3_QUERY_ORIGIN_OUTPUT_ATTR
    RKNN3_QUERY_NATIVE_NHWC_INPUT_ATTR = 10
    RKNN3_QUERY_NATIVE_NHWC_OUTPUT_ATTR = 11

    RKNN3_QUERY_DEVICE_MEM_INFO = 12
    RKNN3_QUERY_CORE_NUMBER = 13
    RKNN3_QUERY_ALLOCATION_INFO = 14
    RKNN3_QUERY_DYNAMIC_SHAPE_CONFIG = 15
    RKNN3_QUERY_DYNAMIC_SHAPE_INFO = 16
    RKNN3_QUERY_LLM_CONFIG = 17
    RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM = 18
    RKNN3_QUERY_POSTPROCESS_OUTPUT_ATTR = 19
    RKNN3_QUERY_POSTPROCESS_DYNAMIC_SHAPE_INFO = 20
    RKNN3_QUERY_LORA_NUM = 21
    RKNN3_QUERY_LORA_INFO = 22

    RKNN3_QUERY_CMD_MAX = 23


class RKNN3TensorType(IntEnum):
    """Tensor data types supported by RKNN3"""
    RKNN3_TENSOR_FLOAT32 = 0
    RKNN3_TENSOR_FLOAT16 = 1
    RKNN3_TENSOR_INT8 = 2
    RKNN3_TENSOR_UINT8 = 3
    RKNN3_TENSOR_INT16 = 4
    RKNN3_TENSOR_UINT16 = 5
    RKNN3_TENSOR_INT32 = 6
    RKNN3_TENSOR_UINT32 = 7
    RKNN3_TENSOR_INT64 = 8
    RKNN3_TENSOR_UINT64 = 9
    RKNN3_TENSOR_BOOL = 10
    RKNN3_TENSOR_INT4 = 11
    RKNN3_TENSOR_FLOAT8E4M3FN = 12
    RKNN3_TENSOR_BFLOAT16 = 13
    RKNN3_TENSOR_FLOAT8E8M0 = 14
    RKNN3_TENSOR_FLOAT4E2M1 = 15

    RKNN3_TENSOR_TYPE_MAX = 16


class RKNN3TensorQntType(IntEnum):
    """Tensor quantization types"""
    RKNN3_TENSOR_QNT_NONE = 0
    RKNN3_TENSOR_PER_LAYER_SYMMETRIC = 1
    RKNN3_TENSOR_PER_LAYER_ASYMMETRIC = 2
    RKNN3_TENSOR_PER_CHANNEL_SYMMETRIC = 3
    RKNN3_TENSOR_PER_CHANNEL_ASYMMETRIC = 4
    RKNN3_TENSOR_PER_GROUP_SYMMETRIC = 5
    RKNN3_TENSOR_PER_GROUP_ASYMMETRIC = 6

    RKNN3_TENSOR_QNT_MAX = auto()


class RKNN3TensorLayout(IntEnum):
    """Tensor layout formats"""
    RKNN3_TENSOR_UNDEFINED = 0
    RKNN3_TENSOR_NCHW = 1
    RKNN3_TENSOR_NHWC = 2
    RKNN3_TENSOR_NC1HWC2 = 3
    RKNN3_TENSOR_CHWN = 4
    RKNN3_TENSOR_HWIO = 5
    RKNN3_TENSOR_OIHW = 6
    RKNN3_TENSOR_O1I1HWI2O2 = 7

    RKNN3_TENSOR_LAYOUT_MAX = auto()


class RKNN3MemAllocFlags(IntEnum):
    """Memory allocation flags"""
    RKNN3_FLAG_MEMORY_FLAGS_DEFAULT = 0 << 0
    RKNN3_FLAG_MEMORY_CACHEABLE = 1 << 0
    RKNN3_FLAG_MEMORY_NON_CACHEABLE = 1 << 1


class RKNN3MemSyncMode(IntEnum):
    """Memory synchronization modes"""
    RKNN3_MEMORY_SYNC_TO_DEVICE = 0x1
    RKNN3_MEMORY_SYNC_FROM_DEVICE = 0x2
    RKNN3_MEMORY_SYNC_BIDIRECTIONAL = RKNN3_MEMORY_SYNC_TO_DEVICE | RKNN3_MEMORY_SYNC_FROM_DEVICE


class RKNN3CoreMask(IntEnum):
    """NPU core mask for multi-core execution"""
    RKNN3_NPU_CORE_AUTO = 0
    RKNN3_NPU_CORE_0 = 1 << 0
    RKNN3_NPU_CORE_1 = 1 << 1
    RKNN3_NPU_CORE_2 = 1 << 2
    RKNN3_NPU_CORE_3 = 1 << 3
    RKNN3_NPU_CORE_4 = 1 << 4
    RKNN3_NPU_CORE_5 = 1 << 5
    RKNN3_NPU_CORE_6 = 1 << 6
    RKNN3_NPU_CORE_7 = 1 << 7
    RKNN3_NPU_CORE_ALL = 0xFFFFFFFF


class RKNN3MemType(IntEnum):
    """Memory type for creating RKNN tensor memory"""
    RKNN3_MEMORY_TYPE_NPU_DRAM = 0 << 0
    RKNN3_MEMORY_TYPE_EXT_DDR = 1 << 0


class RKNN3KVCacheDtype(IntEnum):
    """KV Cache data type"""
    RKNN3_KVCACHE_DTYPE_UNDEFINED = 0
    RKNN3_KVCACHE_DTYPE_INT4_TO_F16 = 1
    RKNN3_KVCACHE_DTYPE_INT4_TO_F8 = 2
    RKNN3_KVCACHE_DTYPE_INT8_TO_F16 = 3
    RKNN3_KVCACHE_DTYPE_FLOAT4_TO_F16 = 4
    RKNN3_KVCACHE_DTYPE_FLOAT4_TO_F8 = 5
    RKNN3_KVCACHE_DTYPE_FLOAT8_TO_F16 = 6
    RKNN3_KVCACHE_DTYPE_FLOAT8_TO_F8 = 7
    RKNN3_KVCACHE_DTYPE_FLOAT16 = 8


class RKNN3KVCacheStoreMethod(IntEnum):
    """KV Cache store method"""
    RKNN3_KVCACHE_STORE_METHOD_UNDEFINED = 0
    RKNN3_KVCACHE_STORE_METHOD_NORMAL = 1
    RKNN3_KVCACHE_STORE_METHOD_GROUP_QUANT = 2


class RKNN3KVCachePolicy(IntEnum):
    """KV Cache policy for LLM"""
    RKNN3_KVCACHE_POLICY_DEFAULT = 0
    RKNN3_KVCACHE_POLICY_RECURRENT = 1
    RKNN3_KVCACHE_POLICY_NORMAL = 2


class RKNN3KVCacheClearPolicy(IntEnum):
    """KV Cache clear policy"""
    RKNN3_KVCACHE_CLEAR_ALL = 0
    RKNN3_KVCACHE_KEEP_SYSTEM_PROMPT = auto()


class RKNN3LLMInputType(IntEnum):
    """LLM input types"""
    RKNN3_LLM_INPUT_PROMPT = 0
    RKNN3_LLM_INPUT_TOKEN = 1
    RKNN3_LLM_INPUT_EMBED = 2
    RKNN3_LLM_INPUT_MULTIMODAL = 3
    RKNN3_LLM_INPUT_AUX = 4

    RKNN3_LLM_INPUT_MAX = auto()


class LLMCallState(IntEnum):
    """LLM callback states"""
    RKLLM_RUN_NORMAL = 0
    RKLLM_RUN_WAITING = 1
    RKLLM_RUN_FINISH = 2
    RKLLM_RUN_STOP = 3
    RKLLM_RUN_MAX_NEW_TOKEN_REACHED = 4
    RKLLM_RUN_ERROR = 5
    RKLLM_RUN_PAUSE = 6
    RKLLM_RUN_RESUME = 7


class LLMOutputCallbackState(IntEnum):
    """LLM output callback states"""
    RKLLM_OUTPUT_CALLBACK_PREFILL_PROCESSING = 0
    RKLLM_OUTPUT_CALLBACK_PREFILL_FINISHED = 1
    RKLLM_OUTPUT_CALLBACK_DECODE_PROCESSING = 2
    RKLLM_OUTPUT_CALLBACK_DECODE_FINISHED = 3


class RKNN3LLMTaskType(IntEnum):
    """LLM task type"""
    RKNN3_LLM_TASK_GENERATE = 0
    RKNN3_LLM_TASK_EMBEDDING = 1


class RKNN3ImFmt(IntEnum):
    """Image format enumeration"""
    RKNN3_IM_FMT_RGB888 = 0
    RKNN3_IM_FMT_BGR888 = 1
    RKNN3_IM_FMT_GRAY8 = 2
    RKNN3_IM_FMT_YCbCr_420_SP = 3
    RKNN3_IM_FMT_YCrCb_420_SP = 4
    RKNN3_IM_FMT_YCbCr_422_SP = 5
    RKNN3_IM_FMT_YCrCb_422_SP = 6
    RKNN3_IM_FMT_UNKNOWN = 0xFFFF


class RKNN3ImProcFlag(IntEnum):
    """Image processing flags enumeration"""
    RKNN3_IM_PROC_FLAG_NONE = 0
    RKNN3_IM_PROC_FLAG_CROP = 1 << 0
    RKNN3_IM_PROC_FLAG_RESIZE = 1 << 1
    RKNN3_IM_PROC_FLAG_FILL = 1 << 5
    RKNN3_IM_PROC_FLAG_COLOR_SPACE_CONVERT = 1 << 6
    RKNN3_IM_PROC_FLAG_DECODE = 1 << 7
    RKNN3_IM_PROC_FLAG_ENCODE = 1 << 8


class RKNN3OpTargetType(IntEnum):
    """Backend execution device for custom operator"""
    RKNN3_OP_TARGET_TYPE_CPU = 1
    RKNN3_OP_TARGET_TYPE_MAX = auto()


class RKNN3OpPluginType(IntEnum):
    """Custom operator plugin type"""
    RKNN3_OP_PLUGIN_TYPE_POSTPROCESS = 0
    RKNN3_OP_PLUGIN_TYPE_CUSTOM_OP = 1
    RKNN3_OP_PLUGIN_TYPE_MAX = auto()


# ============================================= Basic Structures =============================================

class RKNN3InputOutputNum(Structure):
    """Input/Output number information"""
    _fields_ = [
        ("n_input", c_uint32),
        ("n_output", c_uint32)
    ]


class RKNN3QuantInfo(Structure):
    """Quantization information"""
    _fields_ = [
        ("scale", c_float),
        ("zero_point", c_int32)
    ]


class RKNN3TensorAttr(Structure):
    """Tensor attribute information"""
    _fields_ = [
        ("index", c_uint32),
        ("name", c_char * RKNN3_MAX_NAME_LEN),
        ("n_dims", c_uint32),
        ("shape", c_uint32 * RKNN3_MAX_DIMS),
        ("aligned_size", c_uint64),
        ("n_stride", c_uint32),
        ("stride", c_uint64 * RKNN3_MAX_STRIDE_DIMS),
        ("n_elems", c_uint32),
        ("dtype", c_int),
        ("layout", c_int),
        ("qnt_type", c_int),
        ("qnt_info", RKNN3QuantInfo),
        ("core_id", c_int32)
    ]


class RKNN3PerfDetail(Structure):
    """Performance detail information"""
    _fields_ = [
        ("perf_data", c_char_p),
        ("data_len", c_uint64)
    ]


class RKNN3PerfRun(Structure):
    """Performance run information"""
    _fields_ = [
        ("run_duration", c_int64)
    ]


class RKNN3SDKVersion(Structure):
    """SDK version information"""
    _fields_ = [
        ("api_version", c_char * 256),
        ("drv_version", c_char * 256)
    ]


class RKNN3CoreMemSize(Structure):
    """Core memory size information (for RKNN3_QUERY_CORE_MEM_SIZE)"""
    _fields_ = [
        ("core_id", c_int32),
        ("weight_size", c_uint64),
        ("internal_size", c_uint64),
        ("reserved", c_uint8 * 32),
    ]


class RKNN3MemSize(Structure):
    """Memory size information"""
    _fields_ = [
        ("total_const_size", c_uint64), 
        ("total_internal_size", c_uint64),
        ("total_dma_allocated_size", c_uint64),
        ("total_sram_size", c_uint64),
        ("free_sram_size", c_uint64),
    ]


class RKNN3CustomString(Structure):
    """Custom string structure"""
    _fields_ = [
        ("string", c_char * 1024)
    ]


class RKNN3TensorMemory(Structure):
    """Tensor memory information"""
    _fields_ = [
        ("virt_addr", c_void_p),
        ("phys_addr", c_uint64),
        ("fd", c_int32),
        ("buffer_id", c_uint64),
        ("offset", c_uint64),
        ("size", c_uint64),
        ("flags", c_uint64),
        ("core_id", c_int32),
        ("priv_data", c_void_p),
        ("mem_type", c_int),
    ]


class RKNN3Config(Structure):
    """RKNN3 configuration"""
    _fields_ = [
        ("priority", c_int32),
        ("run_timeout", c_uint32),
        ("run_core_mask", c_uint32),
        ("user_mem_weight", c_uint8),
        ("user_mem_internal", c_uint8),
        ("user_sram", c_uint8),
        ("reserved", c_uint8 * 128),
    ]


class RKNN3Tensor(Structure):
    """RKNN3 tensor structure"""
    _fields_ = [
        ("mem", POINTER(RKNN3TensorMemory)),
        ("attr", POINTER(RKNN3TensorAttr))
    ]


class RKNN3AllocationInfo(Structure):
    """Memory allocation information"""
    _fields_ = [
        ("core_id", c_int32),
        ("command_mem", RKNN3TensorMemory),
        ("weight_mem", RKNN3TensorMemory),
        ("internal_mem", RKNN3TensorMemory),
        ("kvcache_mem", RKNN3TensorMemory),
        ("reserved", c_uint8 * 128),
    ]


class RKNN3ShapeInfo(Structure):
    """Shape information for dynamic shape"""
    _fields_ = [
        ("shape_id", c_int32),
        ("n_inputs", c_uint32),
        ("input_attrs", POINTER(RKNN3TensorAttr)),
        ("n_outputs", c_uint32),
        ("output_attrs", POINTER(RKNN3TensorAttr)),
        ("is_default", c_uint8),
        ("reserved", c_uint8 * 31),
    ]


class RKNN3ShapeConfig(Structure):
    """Shape configuration"""
    _fields_ = [
        ("n_shapes", c_uint32),
        ("current_shape_id", c_int32)
    ]


class RKNN3InitExtend(Structure):
    """Extended initialization parameters"""
    _fields_ = [
        ("device_id", c_char_p),
        ("reserved", c_uint8 * 128)
    ]


class RKNN3NodeMemInfo(Structure):
    """Node memory information"""
    _fields_ = [
        ("total", c_uint64),  # Total memory in bytes
        ("free", c_uint64)    # Available memory in bytes
    ]


class RKNN3DevMemInfo(Structure):
    """Device memory information"""
    _fields_ = [
        ("node_num", c_uint32),  # Number of nodes
        ("sys_total", c_uint64),  # Total system memory in bytes
        ("sys_free", c_uint64),   # Available system memory in bytes
        ("node_mem_info", RKNN3NodeMemInfo * RKNN3_MAX_NPU_NODE_NUM)  # Memory info for each node
    ]


class RKNN3Device(Structure):
    """Device information"""
    _fields_ = [
        ("id", c_char * RKNN3_MAX_DEV_LEN),    # Device ID
        ("type", c_char * RKNN3_MAX_DEV_LEN),  # Device type
        ("mem_info", RKNN3DevMemInfo)           # Device memory information
    ]


class RKNN3Devices(Structure):
    """Devices list"""
    _fields_ = [
        ("n_devices", c_uint32),  # Number of devices
        ("devices", RKNN3Device * RKNN3_MAX_DEVS)  # Device information array
    ]


# ============================================= LLM Structures =============================================

class Float16(Structure):
    """Float16 representation"""
    _pack_ = 1
    _fields_ = [
        ("frac", c_uint16, 10),
        ("exp", c_uint16, 5),
        ("sign", c_uint16, 1),
    ]


class RKNN3VocabInfo(Structure):
    """Vocabulary information for LLM"""
    _fields_ = [
        ("vocab_size", c_int),
        ("special_bos_id", c_int * RKNN3_MAX_SPECIAL_BOS_ID_NUM),
        ("special_eos_id", c_int * RKNN3_MAX_SPECIAL_EOS_ID_NUM),
        ("n_special_bos_id", c_int),
        ("n_special_eos_id", c_int),
        ("linefeed_id", c_int),
        ("skip_special_token", c_bool),
        ("ignore_eos_token", c_bool),
        ("reserved", c_uint8 * 64),
    ]


class RKNN3SamplingParams(Structure):
    """Sampling parameters for LLM generation"""
    _fields_ = [
        ('top_k', c_int32),
        ('top_p', c_float),
        ('temperature', c_float),
        ('repeat_penalty', c_float),
        ('frequency_penalty', c_float),
        ('presence_penalty', c_float),
    ]


class RECURRENT(Structure):
    """Recurrent KV cache parameters"""
    _fields_ = [
        ("n_keep", c_int64),
        ("n_keep_aligned", c_int64)
    ]


class RKNN3KVCachePolicyParam(Structure):
    """KV cache policy parameters"""
    _fields_ = [
        ("recurrent", RECURRENT),
        ("reserved", c_uint8 * 64)
    ]


class RKNN3Lora(Structure):
    """LoRA configuration"""
    _fields_ = [
        ("lora_name", c_char * RKNN3_MAX_NAME_LEN),
        ("scale", c_float)
    ]


class RKNN3LLMTensor(Structure):
    """LLM tensor input"""
    _fields_ = [
        ("name", c_char_p),
        ("prompt", c_char_p),
        ("embed", POINTER(Float16)),
        ("tokens", POINTER(c_int32)),
        ("n_tokens", c_uint64),
        ("enable_thinking", c_bool)
    ]


# Auxiliary tensor type (alias)
RKNN3AuxTensor = RKNN3Tensor


class RKNN3Image(Structure):
    """Image input for multimodal LLM"""
    _fields_ = [
        ("image_embed", POINTER(Float16)),  # Embedding of the image
        ("n_image_tokens", c_uint64),  # Number of image tokens
        ("n_image", c_uint64),         # Number of images
        ("image_start", c_char_p),     # Start tag for image in multimodal input
        ("image_end", c_char_p),       # End tag for image in multimodal input
        ("image_content", c_char_p),   # Content tag for image in multimodal input
        ("image_width", c_uint64),     # Width of image
        ("image_height", c_uint64),    # Height of image
    ]


class RKNN3Audio(Structure):
    """Audio input for multimodal LLM"""
    _fields_ = [
        ("audio_embed", POINTER(Float16)),  # Embedding of the audio
        ("n_audio_tokens", c_uint64),  # Number of audio tokens
        ("n_audio", c_uint64),         # Number of audio
        ("audio_start", c_char_p),     # Start tag for audio in multimodal input
        ("audio_end", c_char_p),       # End tag for audio in multimodal input
        ("audio_content", c_char_p),   # Content tag for audio in multimodal input
    ]


class RKNN3Video(Structure):
    """Video input for multimodal LLM"""
    _fields_ = [
        ("video_embed", POINTER(Float16)),  # Embedding of the video
        ("n_frame_tokens", c_uint64),  # Number of frame tokens
        ("n_frame_per_video", c_uint64),  # Number of frames per video
        ("n_video", c_uint64),         # Number of video
        ("video_start", c_char_p),     # Start tag for video in multimodal input
        ("video_end", c_char_p),       # End tag for video in multimodal input
        ("video_content", c_char_p),   # Content tag for video in multimodal input
        ("frame_width", c_uint64),     # Frame width
        ("frame_height", c_uint64),    # Frame height
    ]


class RKNN3LLMMultiModelTensor(Structure):
    """Multimodal tensor input for LLM"""
    _fields_ = [
        ("name", c_char_p),            # Name of this tensor
        ("prompt", c_char_p),          # Text prompt input
        ("tokens", POINTER(c_int32)),  # Array of token IDs
        ("n_tokens", c_uint64),        # Number of token IDs
        ("enable_thinking", c_bool),   # Controls whether "thinking mode" is enabled
        ("image", RKNN3Image),          # Image-related data
        ("audio", RKNN3Audio),          # Audio-related data
        ("video", RKNN3Video),          # Video-related data
    ]


class RKNN3LLMInputUnion(Union):
    """Union for different LLM input types"""
    _fields_ = [
        ("llm_input", RKNN3LLMTensor),
        ("multimodal_input", RKNN3LLMMultiModelTensor),
        ("aux_input", RKNN3AuxTensor)
    ]


class RKNN3LLMInput(Structure):
    """LLM input structure"""
    _fields_ = [
        ("role", c_char_p),
        ("input_type", c_int),
        ("input_union", RKNN3LLMInputUnion)
    ]


class RKNN3LLMExtendParam(Structure):
    """Extended LLM parameters"""
    _fields_ = [
        ("reserved", c_uint8 * 128)
    ]


class RKNN3LLMParam(Structure):
    """LLM parameters"""
    _fields_ = [
        ("logits_name", c_char_p),
        ("max_context_len", c_int32),
        ("sampling_param", RKNN3SamplingParams),
        ("vocab_info", RKNN3VocabInfo),
        ("extend_param", RKNN3LLMExtendParam)
    ]


class RKNN3LLMInferParam(Structure):
    """LLM inference parameters"""
    _fields_ = [
        ("keep_history", c_int),
        ("max_new_tokens", c_int32),
        ("reserved", c_uint8 * 128),
    ]


class RKLLMResult(Structure):
    """LLM generation result"""
    _fields_ = [
        ("token_ids", POINTER(c_int)),
        ("num_tokens", c_int),
    ]


class RKLLMRunState(Structure):
    """LLM runtime state"""
    _fields_ = [
        ("n_total_tokens", c_uint64),
        ("n_max_tokens", c_uint64),
        ("n_decode_tokens", c_uint64),
        ("n_prefill_tokens", c_uint64),
        ("kvcache_policy", c_int),
        ("n_loras_enabled", c_int32),
        ("loras_enabled", POINTER(RKNN3Lora)),
    ]


class RKLLMResultLastHiddenLayer(Structure):
    """Last hidden layer result"""
    _fields_ = [
        ("hidden_states", POINTER(c_float)),
        ("embd_size", c_int),
        ("num_tokens", c_int)
    ]


class RKNN3LLMConfig(Structure):
    """LLM configuration (for RKNN3_QUERY_LLM_CONFIG)"""
    _fields_ = [
        ("chat_template", c_char_p),
        ("vocab_size", c_uint32),
        ("embedding_dim", c_uint32),
        ("max_ctx_len", c_uint32),
        ("max_position_embeddings", c_uint32),
        ("kvcache_store_method", c_int),
        ("kvcache_dtype", c_int),
        ("kvcache_group_size", c_uint32),
        ("kvcache_residual_depth", c_uint32),
        ("model_type", c_char_p),
        ("task_type", c_int),
        ("rope_cache_host_storage", c_uint8),
        ("reserved", c_uint8 * 127),
    ]


class RKNN3ImRect(Structure):
    """Image rectangle structure"""
    _fields_ = [
        ("x", c_int),
        ("y", c_int),
        ("width", c_int),
        ("height", c_int),
    ]


class RKNN3ImMetadata(Structure):
    """Image metadata structure"""
    _fields_ = [
        ("peer_im_mem_addr", c_uint64),
    ]


class RKNN3ImMem(Structure):
    """Image memory information structure"""
    _fields_ = [
        ("width", c_int),
        ("height", c_int),
        ("stride", c_int),
        ("format", c_int),
        ("sync_to_host", c_bool),
        ("data_mem", POINTER(RKNN3TensorMemory)),
        ("metadata", RKNN3ImMetadata),
    ]




# ============================================= Custom Operator Structures =============================================

class RKNN3CustomOpContext(Structure):
    """Custom operator context."""
    _fields_ = [
        ("rknn_ctx", rknn3_context),
        ("priv_data", c_void_p),
        ("user_data", c_void_p),
    ]


RKNN3CustomOpInitCallback = CFUNCTYPE(c_int, POINTER(RKNN3CustomOpContext))
RKNN3CustomOpPrepareCallback = CFUNCTYPE(
    c_int, POINTER(RKNN3CustomOpContext), POINTER(RKNN3Tensor), c_uint32, POINTER(RKNN3Tensor), c_uint32
)
RKNN3CustomOpComputeCallback = CFUNCTYPE(
    c_int, POINTER(RKNN3CustomOpContext), POINTER(RKNN3Tensor), c_uint32, POINTER(RKNN3Tensor), c_uint32
)
RKNN3CustomOpDeinitCallback = CFUNCTYPE(c_int, POINTER(RKNN3CustomOpContext))
RKNN3CustomOpGetOutputNumCallback = CFUNCTYPE(c_int, POINTER(RKNN3CustomOpContext))
RKNN3CustomOpGetAttrsCallback = CFUNCTYPE(
    c_int, POINTER(RKNN3CustomOpContext), POINTER(RKNN3TensorAttr), c_uint32, POINTER(RKNN3TensorAttr), c_uint32
)


class RKNN3CustomOp(Structure):
    """RKNN3 custom operator descriptor."""
    _fields_ = [
        ("op_type", c_char_p),
        ("plugin_type", c_int),
        ("target", c_int),
        ("version", c_uint32),
        ("author", c_char_p),
        ("description", c_char_p),
        ("init", RKNN3CustomOpInitCallback),
        ("prepare", RKNN3CustomOpPrepareCallback),
        ("compute", RKNN3CustomOpComputeCallback),
        ("deinit", RKNN3CustomOpDeinitCallback),
        ("get_output_num", RKNN3CustomOpGetOutputNumCallback),
        ("get_attrs", RKNN3CustomOpGetAttrsCallback),
    ]


RKNN3RegisterCustomOpFunc = CFUNCTYPE(POINTER(RKNN3CustomOp), c_int)

# ============================================= Callback Types =============================================

# LLM Callback function types
LLMResultCallback = CFUNCTYPE(c_int, c_void_p, POINTER(RKLLMResult), c_int)
LLMSamplingCallback = CFUNCTYPE(c_int, c_void_p, POINTER(Float16), c_char_p)
LLMGetEmbedCallback = CFUNCTYPE(c_int, c_void_p, POINTER(c_int32), c_uint64, c_void_p, c_uint64)
LLMTokenizerCallback = CFUNCTYPE(c_int, c_void_p, c_char_p, c_int32, POINTER(c_int32), c_int32)
LLMOutputCallback = CFUNCTYPE(c_int, c_void_p, POINTER(RKNN3Tensor), c_uint32, c_int)


class LLMInputCallbackParam(Structure):
    """Parameters passed to LLMInputCallback."""
    _fields_ = [
        ("tokens", POINTER(c_int32)),
        ("num_tokens", c_int32),
        ("shape_id", c_int32),
        ("pos", c_int32),
        ("reserved", c_uint8 * 128),
    ]


LLMInputCallback = CFUNCTYPE(c_int, c_void_p, POINTER(RKNN3Tensor), c_uint32, LLMInputCallbackParam)


class RKLLMCallback(Structure):
    """LLM callback functions"""
    _fields_ = [
        ("result_callback", LLMResultCallback),
        ("result_userdata", c_void_p),

        ("sampling_callback", LLMSamplingCallback),
        ("sampling_userdata", c_void_p),

        ("tokenizer_callback", LLMTokenizerCallback),
        ("tokenizer_userdata", c_void_p),

        ("embed_callback", LLMGetEmbedCallback),
        ("embed_userdata", c_void_p),

        ("output_callback", LLMOutputCallback),
        ("output_userdata", c_void_p),
        ("output_tensors", POINTER(RKNN3Tensor)),
        ("n_output_tensors", c_uint32),

        ("input_callback", LLMInputCallback),
        ("input_userdata", c_void_p),
        ("input_tensors_index", POINTER(c_int32)),
        ("n_input_tensors", c_uint32),
    ]


# ============================================= Wrapper Classes =============================================

class RKNN3AuxTensorWrapper:
    """Wrapper class for auxiliary tensor"""
    def __init__(self, aux_data=None, index=0, align_size=0):
        self.aux_data = aux_data          # Store numpy array directly
        self.index = index
        self.align_size = align_size


# ============================================= Utility Functions =============================================

def rknn_dtype_to_numpy_dtype(dtype_enum):
    """Convert RKNN3 tensor type to numpy dtype"""
    mapping = {
        RKNN3TensorType.RKNN3_TENSOR_FLOAT32: np.float32,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT16: np.float16,
        RKNN3TensorType.RKNN3_TENSOR_INT8: np.int8,
        RKNN3TensorType.RKNN3_TENSOR_UINT8: np.uint8,
        RKNN3TensorType.RKNN3_TENSOR_INT16: np.int16,
        RKNN3TensorType.RKNN3_TENSOR_UINT16: np.uint16,
        RKNN3TensorType.RKNN3_TENSOR_INT32: np.int32,
        RKNN3TensorType.RKNN3_TENSOR_UINT32: np.uint32,
        RKNN3TensorType.RKNN3_TENSOR_INT64: np.int64,
        RKNN3TensorType.RKNN3_TENSOR_UINT64: np.uint64,
        RKNN3TensorType.RKNN3_TENSOR_BOOL: np.bool_,
        # NumPy has no stable builtin dtype for these packed formats here; expose raw storage.
        RKNN3TensorType.RKNN3_TENSOR_INT4: np.int8,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT8E4M3FN: np.uint8,
        RKNN3TensorType.RKNN3_TENSOR_BFLOAT16: np.uint16,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT8E8M0: np.uint8,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT4E2M1: np.uint8,
    }
    return mapping.get(dtype_enum, np.float32)


def rknn3_get_layout_string(layout):
    """Get layout string from layout enum"""
    try:
        layout_enum = RKNN3TensorLayout(layout)
        layout_map = {
            RKNN3TensorLayout.RKNN3_TENSOR_UNDEFINED: "UNDEFINED",
            RKNN3TensorLayout.RKNN3_TENSOR_NCHW: "NCHW",
            RKNN3TensorLayout.RKNN3_TENSOR_NHWC: "NHWC",
            RKNN3TensorLayout.RKNN3_TENSOR_NC1HWC2: "NC1HWC2",
            RKNN3TensorLayout.RKNN3_TENSOR_CHWN: "CHWN",
            RKNN3TensorLayout.RKNN3_TENSOR_HWIO: "HWIO",
            RKNN3TensorLayout.RKNN3_TENSOR_OIHW: "OIHW",
            RKNN3TensorLayout.RKNN3_TENSOR_O1I1HWI2O2: "O1I1HWI2O2"
        }
        return layout_map.get(layout_enum, "UNKNOWN")
    except ValueError:
        return "UNKNOWN"


def rknn3_get_type_string(dtype):
    """Get data type string from dtype enum"""
    try:
        type_enum = RKNN3TensorType(dtype)
        type_map = {
            RKNN3TensorType.RKNN3_TENSOR_FLOAT32: "FP32",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT16: "FP16",
            RKNN3TensorType.RKNN3_TENSOR_INT8: "INT8",
            RKNN3TensorType.RKNN3_TENSOR_UINT8: "UINT8",
            RKNN3TensorType.RKNN3_TENSOR_INT16: "INT16",
            RKNN3TensorType.RKNN3_TENSOR_UINT16: "UINT16",
            RKNN3TensorType.RKNN3_TENSOR_INT32: "INT32",
            RKNN3TensorType.RKNN3_TENSOR_UINT32: "UINT32",
            RKNN3TensorType.RKNN3_TENSOR_INT64: "INT64",
            RKNN3TensorType.RKNN3_TENSOR_BOOL: "BOOL",
            RKNN3TensorType.RKNN3_TENSOR_INT4: "INT4",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT8E4M3FN: "FLOAT8E4M3FN",
            RKNN3TensorType.RKNN3_TENSOR_BFLOAT16: "BFLOAT16",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT8E8M0: "FLOAT8E8M0",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT4E2M1: "FLOAT4E2M1",
        }
        return type_map.get(type_enum, "UNKNOWN")
    except ValueError:
        return "UNKNOWN"


def rknn3_get_qnt_type_string(qnt_type):
    """Get quantization type string from qnt_type enum"""
    try:
        qnt_enum = RKNN3TensorQntType(qnt_type)
        qnt_map = {
            RKNN3TensorQntType.RKNN3_TENSOR_QNT_NONE: "NONE",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_LAYER_SYMMETRIC: "PER_LAYER_SYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_LAYER_ASYMMETRIC: "PER_LAYER_ASYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_CHANNEL_SYMMETRIC: "PER_CHANNEL_SYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_CHANNEL_ASYMMETRIC: "PER_CHANNEL_ASYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_GROUP_SYMMETRIC: "PER_GROUP_SYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_GROUP_ASYMMETRIC: "PER_GROUP_ASYMMETRIC",
        }
        return qnt_map.get(qnt_enum, "UNKNOWN")
    except ValueError:
        return "UNKNOWN"


def dump_tensor_attr(attr, prefix="tensor"):
    """Print tensor attribute information"""
    shape_list = [attr.shape[i] for i in range(attr.n_dims)]
    stride_list = [attr.stride[i] for i in range(attr.n_stride)]
    
    layout_str = rknn3_get_layout_string(attr.layout)
    dtype_str = rknn3_get_type_string(attr.dtype)
    qnt_type_str = rknn3_get_qnt_type_string(attr.qnt_type)

    try:
        scale_val = attr.qnt_info.scale
        zero_point_val = attr.qnt_info.zero_point
    except AttributeError:
        scale_val = 1.0
        zero_point_val = 0
    
    print(f"{prefix}_{attr.index}: name={attr.name.decode('utf-8', errors='ignore')}, "
          f"n_dims={attr.n_dims}, shape={shape_list}, stride={stride_list}, "
          f"aligned_size={attr.aligned_size}, layout={layout_str}, dtype={dtype_str}, "
          f"qnt_type={qnt_type_str}, scale={scale_val:.5f}, zero_point={zero_point_val}")


def get_os_platform():
    """Get OS platform string"""
    if platform.architecture()[0] == '64bit':
        return platform.system() + '_' + 'x64'
    else:
        return platform.system() + '_' + 'x32'
